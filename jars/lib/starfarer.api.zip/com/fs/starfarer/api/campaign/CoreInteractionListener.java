package com.fs.starfarer.api.campaign;

public interface CoreInteractionListener {
	void coreUIDismissed();
}
