package com.fs.starfarer.api.campaign;

import java.util.List;

/**
 * @author Alex Mosolov
 *
 * Copyright 2012 Fractal Softworks, LLC
 */
public interface FactionAPI {
	float getRelationship(String id);
	void setRelationship(String id, float newValue);
	void adjustRelationship(String id, float amount);
	String getId();
	String getDisplayName();
	
	
	boolean isNeutralFaction();
	boolean isPlayerFaction();
	
	
	List<String> getStockFleetIds();
	//boolean isHostile(FactionAPI other);
}
