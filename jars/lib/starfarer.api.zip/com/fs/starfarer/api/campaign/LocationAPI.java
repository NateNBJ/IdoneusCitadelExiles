package com.fs.starfarer.api.campaign;

import java.awt.Color;
import java.util.List;

import org.lwjgl.util.vector.Vector2f;

import com.fs.starfarer.api.EveryFrameScript;

/**
 * @author Alex Mosolov
 *
 * Copyright 2012 Fractal Softworks, LLC
 */
public interface LocationAPI {
	
	/**
	 * Whether the location's advance() method was/will be called this frame. Always returns true for
	 * the current location.
	 * @return
	 */
	boolean activeThisFrame();
	
	String getBackgroundTextureFilename();
	void setBackgroundTextureFilename(String backgroundTextureFilename);
	
	void addSpawnPoint(SpawnPointPlugin point);
	void removeSpawnPoint(SpawnPointPlugin point);
	List<SpawnPointPlugin> getSpawnPoints();
	
	void spawnFleet(SectorEntityToken anchor, float xOffset, float yOffset, CampaignFleetAPI fleet);

	/**
	 * Not actually added to the location, and doesn't need to be. Can be added via addEntity if it needs to have an orbit.
	 * @param x
	 * @param y
	 * @return
	 */
	SectorEntityToken createToken(float x, float y);
	
	
	void addEntity(SectorEntityToken entity);
	void removeEntity(SectorEntityToken entity);

	
	PlanetAPI addPlanet(SectorEntityToken focus, String name, String type,
						float angle, float radius, float orbitRadius, float orbitDays);
	void addAsteroidBelt(SectorEntityToken focus, int numAsteroids, float orbitRadius, float width, float minOrbitDays, float maxOrbitDays);


	/**
	 * Texture must have vertical, equal width bands in it. Each band must tile vertically with itself.
	 * @param focus
	 * @param category graphics category in settings.json
	 * @param key id within category
	 * @param bandWidthInTexture
	 * @param bandIndex
	 * @param color
	 * @param bandWidthInEngine
	 * @param orbitDays
	 * @param middleRadius
	 * @return
	 */
	SectorEntityToken addRingBand(SectorEntityToken focus, String category, String key,
					 float bandWidthInTexture, int bandIndex, Color color,
					 float bandWidthInEngine, float middleRadius, float orbitDays);

	SectorEntityToken addOrbitalStation(SectorEntityToken focus,
										float angle, float orbitRadius, float orbitDays,
										String name, String factionId);
	
	/**
	 * Examples:
	 * 		getEntities(JumpPointAPI.class) - gets all jump points
	 * 		getEntities(CampaignFleetAPI.class) - gets all fleets
	 * 
	 * General version of getFleets(), getPlanets(), etc
	 * 
	 * @param implementedClassOrInterface
	 * @return
	 */
	List getEntities(Class implementedClassOrInterface);
	
	List<CampaignFleetAPI> getFleets();
	List<PlanetAPI> getPlanets();
	List<SectorEntityToken> getOrbitalStations();
	List<SectorEntityToken> getAsteroids();	
	SectorEntityToken getEntityByName(String name);
	Vector2f getLocation();

	boolean isHyperspace();
	
	/**
	 * Will run every time this location's advance() is called. Note that locations
	 * that are not "current" may run at a lower number of "frames" per second. 
	 * @param script
	 */
	void addScript(EveryFrameScript script);
	void removeScriptsOfClass(Class c);
}





