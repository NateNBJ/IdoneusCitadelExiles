package com.fs.starfarer.api.campaign;

import java.awt.Color;

import com.fs.starfarer.api.combat.BattleCreationContext;

public interface CampaignUIAPI {
	
	void addMessage(String text);
	void addMessage(String text, Color color);
	void addMessage(String text, String highlight, Color highlightColor);
	void addMessage(String text, Color color, String highlight, Color highlightColor);
	
	void clearMessages();
	
	boolean isShowingDialog();
	void startBattle(BattleCreationContext context);
	
	/**
	 * 
	 * @param plugin
	 * @param interactionTarget can be null.
	 */
	void showInteractionDialog(InteractionDialogPlugin plugin, SectorEntityToken interactionTarget);
	
	
	void showCoreUITab(CoreUITabId tab);
}
