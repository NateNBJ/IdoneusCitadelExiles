package com.fs.starfarer.api.campaign.ai;

import java.util.List;

import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.FleetEncounterContextPlugin;
import com.fs.starfarer.api.fleet.CrewCompositionAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;

public interface CampaignFleetAIAPI {
	
	public static enum EncounterOption {
		ENGAGE,
		DISENGAGE,
		HOLD,
		HOLD_VS_STRONGER,
	}
	
	public static enum PostEngagementOption {
		HARRY,
		SALVAGE,
		STAND_DOWN,
	}
	
	public static enum PursuitOption {
		PURSUE,
		HARRY,
		LET_THEM_GO,
	}
	
	public static enum InitialBoardingResponse {
		BOARD,
		ENGAGE,
		LET_IT_GO,
	}
	
	public static enum BoardingActionType {
		HARD_DOCK,
		LAUNCH,
		ABORT,
	}
	
	public static class BoardingActionDecision {
		private BoardingActionType type;
		private CrewCompositionAPI party;
	}
	
	/*
	Whether *wants* to attack, if it were able to
	Engage, flee, or a "let them go, but engage if they engage" behavior
	After a battle, whether it wants to harry, salvage, or stand down	
	*/
	boolean isHostileTo(CampaignFleetAPI other);
	EncounterOption pickEncounterOption(FleetEncounterContextPlugin context, CampaignFleetAPI otherFleet);
	PostEngagementOption pickPostEngagementOption(FleetEncounterContextPlugin context, CampaignFleetAPI otherFleet);
	PursuitOption pickPursuitOption(FleetEncounterContextPlugin context, CampaignFleetAPI otherFleet);
	
	InitialBoardingResponse pickBoardingResponse(FleetEncounterContextPlugin context, FleetMemberAPI toBoard, CampaignFleetAPI otherFleet);
	List<FleetMemberAPI> pickBoardingTaskForce(FleetEncounterContextPlugin context, FleetMemberAPI toBoard, CampaignFleetAPI otherFleet);
	BoardingActionDecision makeBoardingDecision(FleetEncounterContextPlugin context, FleetMemberAPI toBoard, CrewCompositionAPI maxAvailable);
	
	void performCrashMothballingPriorToEscape(FleetEncounterContextPlugin context, CampaignFleetAPI playerFleet);
}










