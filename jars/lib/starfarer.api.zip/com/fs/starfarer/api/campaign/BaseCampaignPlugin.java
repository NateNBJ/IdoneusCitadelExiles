package com.fs.starfarer.api.campaign;

import com.fs.starfarer.api.PluginPick;


/**
 * Extend this class instead of implementing CampaignPlugin for convenience if you do not
 * intend to implement all the methods. This will also help avoid your mod breaking
 * when new methods are added to CampaignPlugin, since default implemenations will be
 * added here and your implementation will inherit them.
 * 
 * @author Alex Mosolov
 *
 * Copyright 2013 Fractal Softworks, LLC
 */
public class BaseCampaignPlugin implements CampaignPlugin {

	public String getId() {
		return null;
	}

	public boolean isTransient() {
		return true;
	}

	public PluginPick<BattleCreationPlugin> pickBattleCreationPlugin(SectorEntityToken opponent) {
		return null;
	}

	public PluginPick<InteractionDialogPlugin> pickInteractionDialogPlugin(SectorEntityToken interactionTarget) {
		return null;
	}

	public PluginPick<BattleAutoresolverPlugin> pickBattleAutoresolverPlugin(SectorEntityToken one, SectorEntityToken two) {
		return null;
	}

}
