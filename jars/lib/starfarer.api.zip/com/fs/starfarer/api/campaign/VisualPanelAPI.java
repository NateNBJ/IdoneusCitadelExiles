package com.fs.starfarer.api.campaign;

import com.fs.starfarer.api.InteractionDialogImageVisual;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;

public interface VisualPanelAPI {
	void setVisualFade(float in, float out);
	
	void showFleetInfo(String titleOne, CampaignFleetAPI one, String titleTwo, CampaignFleetAPI two);
	void showFleetInfo(String titleOne, CampaignFleetAPI one, String titleTwo, CampaignFleetAPI two, FleetEncounterContextPlugin context);
	void showPersonInfo(PersonAPI person);
	void showPlanetInfo(SectorEntityToken planet);
	void showFleetMemberInfo(FleetMemberAPI member);
	
	void showImagePortion(String category, String id,
						  float x, float y, float w, float h,
						  float xOffset, float yOffset,
						  float displayWidth, float displayHeight);
	void showImagePortion(String category, String id,
	 					  float w, float h,
	 					  float xOffset, float yOffset,
	 					  float displayWidth, float displayHeight);
	void showImageVisual(InteractionDialogImageVisual visual);
	
	void showCustomPanel(float width, float height, CustomUIPanelPlugin plugin);
	
	void fadeVisualOut();
	
	void showLoot(String title, CargoAPI otherCargo, CoreInteractionListener listener);
	/**
	 * The noCost parameter isn't used; (other.isFreeTranser() || other.getFaction().isNeutralFaction) is used instead.
	 * Use the other showCore() method.
	 * @param tabId
	 * @param other
	 * @param noCost
	 * @param listener
	 */
	@Deprecated void showCore(CoreUITabId tabId, SectorEntityToken other, boolean noCost, CoreInteractionListener listener);
	
	void showCore(CoreUITabId tabId, SectorEntityToken other, CoreInteractionListener listener);
}
