package com.fs.starfarer.api.campaign;

import com.fs.starfarer.api.combat.EngagementResultAPI;

public interface InteractionDialogPlugin {
	void init(InteractionDialogAPI dialog);
	void optionSelected(String optionText, Object optionData);
	void optionMousedOver(String optionText, Object optionData);
	
	void advance(float amount);
	

	void backFromEngagement(EngagementResultAPI battleResult);
	
	Object getContext();
}
