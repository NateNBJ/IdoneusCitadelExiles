package com.fs.starfarer.api.campaign;

import java.awt.Color;

import org.lwjgl.util.vector.Vector2f;

/**
 * @author Alex Mosolov
 *
 * Copyright 2012 Fractal Softworks, LLC
 */
public interface StarSystemAPI extends LocationAPI {

	
	Vector2f getLocation();

	String getName();
	void setName(String name);
	
	/**
	 * Should not be used unless a star system disconnected from hyperspace (or not connected
	 * in the usual way) is desired.
	 * @param type
	 * @param color
	 * @param radius
	 * @return
	 */
	PlanetAPI initStar(String type, float radius);
	
	
	/**
	 * Color argument is not used. Use PlanetAPI.getSpec() instead.
	 * 
	 */
	@Deprecated PlanetAPI initStar(String type, Color color, float radius);
	
	
	/**
	 * Also automatically creates a wormhole/jump point leading to the star from hyperspace. This
	 * wormhole can be accessed using getHyperspaceAnchor().
	 * @param type
	 * @param color
	 * @param radius
	 * @param hyperspaceLocationX
	 * @param hyperspaceLocationY
	 * @return
	 */
	PlanetAPI initStar(String type, float radius, float hyperspaceLocationX, float hyperspaceLocationY);
	
	
	/**
	 * @return wormhole leading to the star system's sun, if such a wormhole exists.
	 */
	JumpPointAPI getHyperspaceAnchor();
	
	void setHyperspaceAnchor(JumpPointAPI hyperspaceAnchor);
	
	
	PlanetAPI getStar();
	
	
	/**
	 * Calls autogenerateHyperspaceJumpPoints(false, false)
	 */
	void autogenerateHyperspaceJumpPoints();
	
	
	/**
	 * Generates jump points into the system and adds them to hyperspace.
	 * 
	 * Jump points generated are based on the jump points within the system.
	 * 
	 * Also adds jump destinations from all in-system jump points to the associated,
	 * newly-generated hyperspace jump points.
	 * 
	 * Will also generate a wormhole for the star if one doesn't exist already.
	 * 
	 * @param generateEntrancesAtGasGiants whether one-way jump points into the system are generated at gas giants
	 * @param generateFringeJumpPoint whether an extra jump point (two-way) is generated on the fringes of the system
	 */
	void autogenerateHyperspaceJumpPoints(boolean generateEntrancesAtGasGiants, boolean generateFringeJumpPoint);
	
	
	Color getLightColor();
	/**
	 * Only applicable if this location has a light source (i.e. a star).
	 * @param lightColor
	 */
	void setLightColor(Color lightColor);
}
