package com.fs.starfarer.api.campaign;

import java.awt.Color;
import java.util.List;
import java.util.Map;

import org.lwjgl.util.vector.Vector2f;

import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.campaign.JumpPointAPI.JumpDestination;


/**
 * Note: generics can not be used in scripts.
 * They are used in this API purely to show the return/parameter types of functions more clearly.
 * @author Alex Mosolov
 *
 * Copyright 2012 Fractal Softworks, LLC
 */
@SuppressWarnings("unchecked")
public interface SectorAPI {
	
	/**
	 * Can be used (including by classes that are not part of the savegame - i.e. ModPlugin or 
	 * transient CampaignPlugin implementations) to save data between sessions.
	 * @return
	 */
	Map<String, Object> getPersistentData();
	
	void registerPlugin(CampaignPlugin plugin);
	void unregisterPlugin(String pluginId);
	
	StarSystemAPI getStarSystem(String name);
	StarSystemAPI createStarSystem(String name);
	List<StarSystemAPI> getStarSystems();
	void removeStarSystem(StarSystemAPI system);
	void setCurrentLocation(LocationAPI location);
	
	LocationAPI getHyperspace();
	
	/**
	 * @param fleet
	 * @param jumpLocation can be null. If not, fleet will attempt to reach it before jumping. Failure will result in aborted jump.
	 * @param dest
	 */
	void doHyperspaceTransition(CampaignFleetAPI fleet, SectorEntityToken jumpLocation, JumpDestination dest);
	
	
	CampaignFleetAPI createFleet(String factionId, String fleetTypeId);
	CampaignClockAPI getClock();
	
	CampaignFleetAPI getPlayerFleet();
	
	FactionAPI getFaction(String factionId);
	List<FactionAPI> getAllFactions();
	
	List<String> getAllWeaponIds();
	List<String> getAllEmptyVariantIds();
	List<String> getAllFighterWingIds();
	
	
	CampaignUIAPI getCampaignUI();
	
	void setPaused(boolean paused);
	boolean isPaused();
	
	void addScript(EveryFrameScript script);
	void removeScriptsOfClass(Class c);
	
	
	/**
	 * Use SectorAPI.getCampaignUI.addMessage instead.
	 * @param text
	 */
	@Deprecated void addMessage(String text);
	
	/**
	 * Use SectorAPI.getCampaignUI.addMessage instead.
	 * @param text
	 */
	@Deprecated void addMessage(String text, Color color);
	
	/**
	 * Use SectorAPI.getCampaignUI.addMessage instead.
	 * @param text
	 */
	@Deprecated void addMessage(String text, String highlight, Color highlightColor);
	
	/**
	 * Use SectorAPI.getCampaignUI.addMessage instead.
	 * @param text
	 */
	@Deprecated void addMessage(String text, Color color, String highlight, Color highlightColor);


	
	LocationAPI getCurrentLocation();
	
	LocationAPI getRespawnLocation();
	void setRespawnLocation(LocationAPI respawnLocation);
	Vector2f getRespawnCoordinates();
}
