package com.fs.starfarer.api.campaign;

import org.lwjgl.util.vector.Vector2f;

import com.fs.starfarer.api.Script;
import com.fs.starfarer.api.campaign.ai.CampaignFleetAIAPI;
import com.fs.starfarer.api.characters.MutableCharacterStatsAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.fleet.FleetLogisticsAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.fleet.MutableFleetStatsAPI;

/**
 * @author Alex Mosolov
 *
 * Copyright 2012 Fractal Softworks, LLC
 */
public interface CampaignFleetAPI extends SectorEntityToken {

	 /**
	 * @return whether the fleet's LocationAPI is the same one the player's fleet is currently in.
	 */
	boolean isInCurrentLocation();
	boolean isInHyperspace();
	
	/**
	 * Use this to set the location. DO NOT use getLocation().x = <new x> etc, that won't work.
	 * @param x
	 * @param y
	 */
	void setLocation(float x, float y);
	
	boolean isAlive();
	
	void addAssignment(FleetAssignment assignment, SectorEntityToken target, float maxDurationInDays);
	void addAssignment(FleetAssignment assignment, SectorEntityToken target, float maxDurationInDays, Script onCompletion);
	void clearAssignments();
	void setPreferredResupplyLocation(SectorEntityToken token);
	
	
	//FactionAPI getFaction();
	Vector2f getVelocity();
	
	/* (non-Javadoc)
	 * Do not use to set the location, it won't work.
	 * 
	 * Use setLocation instead.
	 * @see com.fs.starfarer.api.campaign.SectorEntityToken#getLocation()
	 */
	Vector2f getLocation();
	
	FleetLogisticsAPI getLogistics();
	
	LocationAPI getContainingLocation();
	
	PersonAPI getCommander();
	MutableCharacterStatsAPI getCommanderStats();
	FleetMemberAPI getFlagship();
	boolean isPlayerFleet();
	
	FleetDataAPI getFleetData();
//	List<FleetMemberAPI> getMembersListCopy();
//	List<FleetMemberAPI> getCombatReadyMembersListCopy();
//	int getFleetPoints();
//	void addFleetMember(FleetMemberAPI member);
//	void removeFleetMember(FleetMemberAPI member);
	
	void removeFleetMemberWithDestructionFlash(FleetMemberAPI member);
	
	void setName(String name);
	float getTotalSupplyCostPerDay();
	int getNumCapitals();
	int getNumCruisers();
	int getNumDestroyers();
	int getNumFrigates();
	int getNumFighters();
	
	float getTravelSpeed();
	
	CampaignFleetAIAPI getAI();

	int getFleetPoints();

	String getNameWithFaction();
	String getName();
	
	/**
	 * @return true if the fleet is not empty and doesn't consist entirely of fighter wings.
	 */
	boolean isValidPlayerFleet();

	void setNoEngaging(float seconds);

	MutableFleetStatsAPI getStats();

	
	/**
	 * Used by the AI to control the fleet as well, so it's not a reliable way to
	 * order a fleet around as the AI will be calling this method every frame.
	 * @param x
	 * @param y
	 */
	void setMoveDestination(float x, float y);
	
	/**
	 * Overrides AI and player input.
	 * @param x
	 * @param y
	 */
	void setMoveDestinationOverride(float x, float y);
	
	/**
	 * The fleet is trying to interact with this entity - i.e. engage an enemy fleet, use a wormhole, etc.
	 * @return
	 */
	SectorEntityToken getInteractionTarget();
	
	void setInteractionTarget(SectorEntityToken target);
	
	boolean isInHyperspaceTransition();
}




