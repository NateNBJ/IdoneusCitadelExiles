package com.fs.starfarer.api.campaign;

import java.util.List;

import com.fs.starfarer.api.fleet.FleetMemberAPI;

public interface FleetDataAPI {
	/**
	 * Returns:
	 * "logistical priority" members first, then non-mothballed, then mothballed.
	 * Retains normal order within each category.
	 * @return
	 */
	List<FleetMemberAPI> getMembersInPriorityOrder();
	
	List<FleetMemberAPI> getMembersListCopy();
	List<FleetMemberAPI> getCombatReadyMembersListCopy();
	float getFleetPointsUsed();
	void addFleetMember(FleetMemberAPI member);
	void removeFleetMember(FleetMemberAPI member);
	
	void clear();
	
	/**
	 * Removes from the fleet, adds fuel/supplies gained from scuttling, adds
	 * any equipped weapons to cargo.
	 * @param member
	 */
	void scuttle(FleetMemberAPI member);
	
	/**
	 * Maximum burn level of fastest ship in the fleet. Includes getStats().getFleetwideMaxBurnMod().
	 * @return
	 */
	float getMaxBurnLevel();
	
	/**
	 * Maximum burn level of slowest ship in the fleet. Includes getStats().getFleetwideMaxBurnMod()
	 * @return
	 */
	float getMinBurnLevel();
	
	
	/**
	 * Effective burn level this fleet can go at; includes effect of being in deep hyperspace (where getMinBurnLevel() does not).
	 * @return
	 */
	float getBurnLevel();

	/**
	 * Will also set the captains of all the other ships to a new person with all-0 stats.
	 * @param flagship
	 */
	void setFlagship(FleetMemberAPI flagship);

	
	CampaignFleetAPI getFleet();
}
