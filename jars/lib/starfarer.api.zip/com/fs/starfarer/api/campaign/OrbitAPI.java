package com.fs.starfarer.api.campaign;

/**
 * @author Alex Mosolov
 *
 * Copyright 2012 Fractal Softworks, LLC
 */
public interface OrbitAPI {
	SectorEntityToken getFocus();
	void advance(float amount);
	
	/**
	 * @param entity entity that's doing the orbiting.
	 */
	void setEntity(SectorEntityToken entity);

}
