package com.fs.starfarer.api.campaign;

import java.awt.Color;

public interface TextPanelAPI {
	void addParagraph(String text);
	void addParagraph(String text, Color color);
	void replaceLastParagraph(String text);
	void replaceLastParagraph(String text, Color color);
	void appendToLastParagraph(String text);
	
	void highlightFirstInLastPara(String text, Color color);
	void highlightLastInLastPara(String text, Color color);
	void highlightInLastPara(Color color, String ...strings);
	
	/**
	 * Must be in order they appear in the paragraph.
	 * @param strings
	 */
	void highlightInLastPara(String ...strings);
	void setHighlightColorsInLastPara(Color ...colors);
}
