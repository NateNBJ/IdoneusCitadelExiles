package com.fs.starfarer.api.campaign;

import org.lwjgl.util.vector.Vector2f;

import com.fs.starfarer.api.InteractionDialogImageVisual;


/**
 * @author Alex Mosolov
 *
 * Copyright 2012 Fractal Softworks, LLC
 */
public interface SectorEntityToken {
	
	CargoAPI getCargo();
	Vector2f getLocation();
	OrbitAPI getOrbit();
	void setOrbit(OrbitAPI orbit);
	
	
	Object getName();
	String getFullName();
	
	void setFaction(String factionId);
	LocationAPI getContainingLocation();
	
	float getRadius();
	
	FactionAPI getFaction();
	
	String getCustomDescriptionId();
	void setCustomDescriptionId(String customDescriptionId);
	
	void setCustomInteractionDialogImageVisual(InteractionDialogImageVisual visual);
	InteractionDialogImageVisual getCustomInteractionDialogImageVisual();
	
	/**
	 * Whether moving ships and items to and from this entity has a cost.
	 * @param freeTransfer
	 */
	public void setFreeTransfer(boolean freeTransfer);
	public boolean isFreeTransfer();
}




