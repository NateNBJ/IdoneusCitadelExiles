package com.fs.starfarer.api.campaign;


public interface CargoStackAPI {
	
	public boolean isWeaponStack();
	public boolean isResourceStack();
	public boolean isMarineStack();
	public boolean isFuelStack();
	public boolean isSupplyStack();
	public boolean isCrewStack();
	public boolean isBlueprintStack();
	
	/**
	 * @return crew XP level, or null if it's not a crew stack
	 */
	public CargoAPI.CrewXPLevel getCrewXPLevel();
	
	public float getCargoSpace();
	public float getCargoSpacePerUnit();

	
	public float getSize();
	public float getFree();
	public void setSize(float size);
	public void add(float quantity);
	public void subtract(float quantity);
	
	public float getMaxSize();
	public boolean isFull();

	public CargoAPI.CargoItemType getType();
	public void setType(CargoAPI.CargoItemType type);
	
	/**
	 * If true, it's an empty cargo stack. These get created for spacing, a result of the player moving cargo around.
	 * @return
	 */
	public boolean isNull();
	
	
	/**
	 * Usually a String. Its contents (i.e. the resource id) is how you can tell apart different types of resources.
	 * @return
	 */
	public Object getData();

	// these concepts might not survive an actual economy implementation
//	public int getBaseValue();
//	public int getBaseValuePerUnit();
	
	public String getDisplayName();
	
	/**
	 * @return CargoAPI that contains this stack.
	 */
	public CargoAPI getCargo();
}
