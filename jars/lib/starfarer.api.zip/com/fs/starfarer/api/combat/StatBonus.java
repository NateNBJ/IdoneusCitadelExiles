package com.fs.starfarer.api.combat;

import java.util.HashMap;

import com.fs.starfarer.api.combat.MutableStat.StatMod;
import com.fs.starfarer.api.combat.MutableStat.StatModType;

/**
 * @author Alex Mosolov
 *
 * Copyright 2012 Fractal Softworks, LLC
 */
public class StatBonus {

	public float flatBonus = 0f;
	public float mult = 1f;
	
	//private List<StatMod> mods = new LinkedList<StatMod>();
	private HashMap<String, StatMod> flatBonuses = new HashMap<String, StatMod>();
	private HashMap<String, StatMod> percentBonuses = new HashMap<String, StatMod>();
	private HashMap<String, StatMod> multBonuses = new HashMap<String, StatMod>();
	
	private boolean needsRecompute = false;
	public StatBonus() {
	}
	
	Object readResolve() {
		if (multBonuses == null) {
			multBonuses = new HashMap<String, StatMod>();
		}
		return this;
	}
	
	public StatMod getFlatBonus(String source) {
		return flatBonuses.get(source);
	}
	
	public StatMod getPercentBonus(String source) {
		return percentBonuses.get(source);
	}
	
	public StatMod getMultBonus(String source) {
		return multBonuses.get(source);
	}
	
	public void modifyFlat(String source, float value) {
		modifyFlat(source, value, null);
	}
	public void modifyFlat(String source, float value, String desc) {
		StatMod mod = flatBonuses.get(source);
		if (mod == null && value == 0) return;
		if (mod != null && mod.value == value) return;
		
		mod = new StatMod(source, StatModType.FLAT, value, desc);
		flatBonuses.put(source, mod);
		needsRecompute = true;
	}
	
	public void modifyPercent(String source, float value) {
		modifyPercent(source, value, null);
	}
	
	public void modifyPercent(String source, float value, String desc) {
		StatMod mod = percentBonuses.get(source);
		if (mod == null && value == 0) return;
		if (mod != null && mod.value == value) return;
		
		mod = new StatMod(source, StatModType.PERCENT, value, desc);
		percentBonuses.put(source, mod);
		needsRecompute = true;
	}
	
	public void modifyMult(String source, float value) {
		modifyMult(source, value, null);
	}
	public void modifyMult(String source, float value, String desc) {
		StatMod mod = multBonuses.get(source);
		if (mod == null && value == 1) return;
		if (mod != null && mod.value == value) return;
		
		mod = new StatMod(source, StatModType.MULT, value, desc);
		multBonuses.put(source, mod);
		needsRecompute = true;
	}
	
	public void unmodify() {
		flatBonuses.clear();
		percentBonuses.clear();
		multBonuses.clear();
		needsRecompute = true;
	}
	
	public void unmodify(String source) {
		StatMod mod = flatBonuses.remove(source);
		if (mod != null && mod.value != 0) needsRecompute = true; 
		mod = percentBonuses.remove(source);
		if (mod != null && mod.value != 0) needsRecompute = true;
		mod = multBonuses.remove(source);
		if (mod != null && mod.value != 1) needsRecompute = true;
	}
	
	public void unmodifyFlat(String source) {
		StatMod mod = flatBonuses.remove(source);
		if (mod != null && mod.value != 0) needsRecompute = true;
	}
	
	public void unmodifyPercent(String source) {
		StatMod mod = percentBonuses.remove(source);
		if (mod != null && mod.value != 0) needsRecompute = true;
	}
	
	public void unmodifyMult(String source) {
		StatMod mod = multBonuses.remove(source);
		if (mod != null && mod.value != 1) needsRecompute = true;
	}	
	
	private void recompute() {
		float flatMod = 0;
		float percentMod = 0;
		float multBonus = 1f;
		for (StatMod mod : percentBonuses.values()) {
			percentMod += mod.value;
		}
		for (StatMod mod : flatBonuses.values()) {
			flatMod += mod.value;
		}
		for (StatMod mod : multBonuses.values()) {
			multBonus *= mod.value;
		}
		
		mult = 1f + percentMod / 100f;
		if (mult < 0) mult = 0;
		mult *= multBonus;
		
		flatBonus = flatMod;
		
		needsRecompute = false;
	}
	
	public float computeEffective(float baseValue) {
		if (needsRecompute) recompute();
		return baseValue * mult + flatBonus;
	}

	public float getFlatBonus() {
		if (needsRecompute) recompute();
		return flatBonus;
	}
	
	public float getBonusMult() {
		if (needsRecompute) recompute();
		return mult;
	}
	
	public boolean isPositive(float baseValue) {
		return computeEffective(baseValue) > baseValue;
	}
	
	public boolean isNegative(float baseValue) {
		return computeEffective(baseValue) < baseValue;
	}

	public HashMap<String, StatMod> getFlatBonuses() {
		return flatBonuses;
	}

	public HashMap<String, StatMod> getPercentBonuses() {
		return percentBonuses;
	}

	public HashMap<String, StatMod> getMultBonuses() {
		return multBonuses;
	}
	
	public void applyMods(MutableStat other) {
		flatBonuses.putAll(other.getFlatMods());
		percentBonuses.putAll(other.getPercentMods());
		multBonuses.putAll(other.getMultMods());
		needsRecompute = true;
	}
	
	public void applyMods(StatBonus other) {
		flatBonuses.putAll(other.getFlatBonuses());
		percentBonuses.putAll(other.getPercentBonuses());
		multBonuses.putAll(other.getMultBonuses());
		needsRecompute = true;
	}
}











