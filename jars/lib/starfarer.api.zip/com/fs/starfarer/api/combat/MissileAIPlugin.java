package com.fs.starfarer.api.combat;


/**
 * NOTE: An implementation of this should almost always also implement GuidedMissileAI, this is required
 * for the missile to be properly affected by flares.
 * 
 * @author Alex Mosolov
 *
 * Copyright 2013 Fractal Softworks, LLC
 */
public interface MissileAIPlugin {
	/**
	 * The AI should do its main work here.
	 * @param amount
	 */
	void advance(float amount);
}
