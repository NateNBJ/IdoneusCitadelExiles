package com.fs.starfarer.api.combat;

public interface ShipSystemAPI {
	
	String getId();
	
	float getCooldownRemaining();
	boolean isOutOfAmmo();
	/**
	 * @return true if the system is charging up, down, or is on.
	 */
	boolean isActive();
	
	boolean isCoolingDown();
	
	int getAmmo();
	
	float getFluxPerUse();
	float getFluxPerSecond();
	
	String getDisplayName();
	
	/**
	 * @return true if the system is charging up or is on.
	 */
	boolean isOn();
}
