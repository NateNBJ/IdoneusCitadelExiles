package com.fs.starfarer.api.combat;

import com.fs.starfarer.api.fleet.FleetMemberAPI;

/**
 * Used in combat to relate a deployed ship or fighter wing to the associated FleetMemberAPI.
 * 
 * @author Alex Mosolov
 *
 * Copyright 2013 Fractal Softworks, LLC
 */


public interface DeployedFleetMemberAPI {

	FleetMemberAPI getMember();

	boolean isFighterWing();

	/**
	 * @return Ship or wing leader.
	 */
	ShipAPI getShip();

}
