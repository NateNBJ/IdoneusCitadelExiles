package com.fs.starfarer.api.combat;

import java.util.List;

import org.lwjgl.util.vector.Vector2f;

import com.fs.starfarer.api.campaign.CargoAPI.CrewXPLevel;
import com.fs.starfarer.api.fleet.FleetMemberAPI;

/**
 * @author Alex Mosolov
 *
 * Copyright 2012 Fractal Softworks, LLC
 */
public interface CombatFleetManagerAPI {
	public interface AssignmentInfo {
		CombatAssignmentType getType();
		AssignmentTargetAPI getTarget();
	}
	
	
	public MutableStat getCommandPointsStat();
	public MutableStat getMaxFleetPoints();
	
	/**
	 * Deploy a ship/fighter wing with the given spec or variant id.
	 * 
	 * If there isn't one in the reserves, a temporary FleetMemberAPI is created and added to the reserves
	 * (but not the underlying CampaignFleetAPI, if any)
	 * 
	 * @param id
	 * @param location Where to deploy.
	 * @param facing Facing at time of deployment.
	 * @return
	 */
	public ShipAPI spawnShipOrWing(String specId, Vector2f location, float facing);
	
	/**
	 * Deploy a ship/fighter wing with the given spec or variant id.
	 * 
	 * If there isn't one in the reserves, a temporary FleetMemberAPI is created and added to the reserves
	 * (but not the underlying CampaignFleetAPI, if any)
	 * @param specId
	 * @param location
	 * @param facing
	 * @param level crew experience level
	 * @param initialBurnDur amount of time travel drive should be on (in seconds)
	 * @return
	 */
	public ShipAPI spawnShipOrWing(String specId, Vector2f location, float facing, CrewXPLevel level, float initialBurnDur);
	
	/**
	 * member does not actually have to be in the reserves.
	 * @param member
	 * @param location
	 * @param facing
	 * @param initialBurnDur
	 * @return
	 */
	public ShipAPI spawnFleetMember(FleetMemberAPI member, Vector2f location, float facing, float initialBurnDur);

	
	
	/**
	 * Returns ship that corresponds to the fleet member passed in. Returns the wing leader for fighter wings.
	 * @param fleetMember
	 * @return
	 */
	public ShipAPI getShipFor(FleetMemberAPI fleetMember);
	
	public List<FleetMemberAPI> getDeployedCopy(); 
	public List<FleetMemberAPI> getReservesCopy(); 
	
	
	/**
	 * Returns the current assignment for a ship (the assignment type, and the target, if any).
	 * Returns null if there isn't one (i.e. the ship is on a default search-and-destroy).
	 * 
	 * For fighter wings, can pass in any fighter from the wing to get the assignment.
	 * 
	 * @param ship
	 * @return
	 */
	AssignmentInfo getAssignmentFor(ShipAPI ship);
	List<AssignmentInfo> getAllAssignments();
	
	DeployedFleetMemberAPI getDeployedFleetMember(ShipAPI ship);
	AssignmentTargetAPI createWaypoint(Vector2f location);
	
	/**
	 * target should be one of:
	 * 	BattleObjectiveAPI
	 * 	DeployedFleetMemberAPI
	 * 	the result of createWaypoint()
	 * 
	 * @param type
	 * @param target
	 * @param useCommandPointIfNeeded
	 * @return
	 */
	AssignmentInfo createAssignment(CombatAssignmentType type, AssignmentTargetAPI target, boolean useCommandPoint);
	
	void giveAssignment(DeployedFleetMemberAPI member, AssignmentInfo assignment, boolean useCommandPointIfNeeded);
	void orderRetreat(DeployedFleetMemberAPI member, boolean useCommandPointIfNeeded);
	void orderSearchAndDestroy(DeployedFleetMemberAPI member, boolean useCommandPointIfNeeded);
	
	/**
	 * Cancels all assignments. New assignments can still be created.
	 */
	void orderSearchAndDestroy();
	
	/**
	 * Cancels all assignment and orders all ships to retreat. Can not be aborted.
	 */
	void orderFullRetreat();
	
	
}



