package com.fs.starfarer.api.combat;

import org.lwjgl.util.vector.Vector2f;

public interface BeamAPI {
	
	Vector2f getFrom();
	Vector2f getTo();
	
	WeaponAPI getWeapon();
	ShipAPI getSource();
	
	boolean didDamageThisFrame();
	CombatEntityAPI getDamageTarget();
	
	float getBrightness();
}
