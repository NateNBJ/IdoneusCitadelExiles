package com.fs.starfarer.api.combat;

import com.fs.starfarer.api.campaign.EngagementResultForFleetAPI;

public interface EngagementResultAPI {

	EngagementResultForFleetAPI getWinnerResult();
	EngagementResultForFleetAPI getLoserResult();
	
	boolean didPlayerWin();
	
	
//	/**
//	 * Applies ship and crew losses from the engagement to the fleets involved.
//	 */
//	void applyToFleets();
}
