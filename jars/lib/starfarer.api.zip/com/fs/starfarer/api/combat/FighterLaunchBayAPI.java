package com.fs.starfarer.api.combat;

import org.lwjgl.util.vector.Vector2f;

public interface FighterLaunchBayAPI {
	
	/**
	 * Absolute location the fighter should be heading for landing.
	 * @param fighter
	 * @return
	 */
	Vector2f getLandingLocation(ShipAPI fighter);
	
	
	
	/**
	 * This removes the fighter from the engine, so its AI methods will stop being called.
	 * When the fighter is re-launched, a new AI will be created.
	 * @param fighter
	 */
	void land(ShipAPI fighter);
	
	
	/**
	 * Which fighter the launch bay expects to land. Only the fighter returned by this method
	 * should call the land() method; other fighters should hang around the carrier and wait their
	 * turn.
	 * @param fighter
	 */
	ShipAPI getIncomingFighter();
	
	
	/**
	 * @return The ship that this launch bay is on.
	 */
	ShipAPI getShip();
}
