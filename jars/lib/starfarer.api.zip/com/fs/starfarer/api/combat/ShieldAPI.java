package com.fs.starfarer.api.combat;

import org.lwjgl.util.vector.Vector2f;


/**
 * @author Alex Mosolov
 *
 * Copyright 2012 Fractal Softworks, LLC
 */
public interface ShieldAPI {
	
	public static enum ShieldType {NONE, FRONT, OMNI, PHASE}

	void setType(ShieldType type);
	ShieldType getType();
	
	float getFacing();
	
	
	/**
	 * @return maximum arc.
	 */
	float getArc();
	/**
	 * @return currently open arc (0 if not on)
	 */
	float getActiveArc();
	void setActiveArc(float activeArc);
	float getRadius();
	boolean isOn();
	boolean isOff();
	
	/**
	 * @return location of the center of the shield, in engine coordinates.
	 */
	Vector2f getLocation();
	
	boolean isWithinArc(Vector2f point);
	
	void toggleOff();
}
