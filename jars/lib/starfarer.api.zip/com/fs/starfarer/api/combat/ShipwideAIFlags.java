package com.fs.starfarer.api.combat;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ShipwideAIFlags {
	public static enum AIFlags {
		DO_NOT_USE_FLUX,
		DO_NOT_VENT,
		DO_NOT_AUTOFIRE_NON_ESSENTIAL_GROUPS,
		RUN_QUICKLY,
		TURN_QUICKLY,
		PURSUING,
		HAS_INCOMING_DAMAGE,
		KEEP_SHIELDS_ON,
		BACK_OFF,
		
		/**
		 * Fighters only, is set when committed to an attack run. 
		 */
		IN_ATTACK_RUN,
		
		/**
		 * Whether the ship wants to be escorted by nearby friendlies. 
		 */
		NEEDS_HELP,
	}
	
	public static final float FLAG_DURATION = 0.5f;
	
	private class FlagData {
		AIFlags flag;
		float elapsed;
		private FlagData(AIFlags flag) {
			super();
			this.flag = flag;
		}
	}
	

	private Map<AIFlags, FlagData> flags = new HashMap<AIFlags, FlagData>();
	
	public void setFlag(AIFlags flag) {
		FlagData data = flags.get(flag);
		if (data != null) {
			data.elapsed = 0;
		} else {
			flags.put(flag, new FlagData(flag));
		}
	}
	
	public void removeFlag(AIFlags flag) {
		flags.remove(flag);
	}
	
	public void advance(float amount) {
		List<AIFlags> remove = new ArrayList<AIFlags>();
		for (AIFlags flag : flags.keySet()) {
			FlagData data = flags.get(flag);
			data.elapsed += amount;
			if (data.elapsed > FLAG_DURATION) {
				remove.add(flag);
			}
		}
		for (AIFlags flag : remove) {
			flags.remove(flag);
		}
	}
	
	/**
	 * Checks whether a specific AI flag is set.
	 * This is how different ship AI modules communicate with each other, when they need to.
	 * @param flag
	 * @return
	 */
	public boolean hasFlag(AIFlags flag) {
		return flags.containsKey(flag);
	}
}








