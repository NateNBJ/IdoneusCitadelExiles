/**
 * 
 */
package com.fs.starfarer.api.combat;


public enum DamageType {
	KINETIC(2.0f,0.5f,1.0f, "Kinetic"),
	HIGH_EXPLOSIVE(0.5f,2.0f,1.0f, "High Explosive"),
	FRAGMENTATION(0.25f,0.25f,1.0f, "Fragmentation"),
	ENERGY(1.0f,1.0f,1.0f, "Energy"),
	OTHER(1f,1f,1f, "Other"); // fighter launchers, etc - where damage type doesn't apply
	

	private DamageType(float shieldMult, float armorMult, float hullMult, String displayName) {
		this.shieldMult = shieldMult;
		this.armorMult = armorMult;
		this.hullMult = hullMult;
		this.displayName = displayName;
	}
	
	private final String displayName;
	private float shieldMult;
	private float armorMult;
	private float hullMult;
	
	public float getShieldMult() {
		return shieldMult;
	}
	public float getArmorMult() {
		return armorMult;
	}
	public float getHullMult() {
		return hullMult;
	}
	public String getDisplayName() {
		return displayName;
	}
}