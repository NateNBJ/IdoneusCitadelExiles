package com.fs.starfarer.api.combat;

import java.util.HashMap;

/**
 * @author Alex Mosolov
 *
 * Copyright 2012 Fractal Softworks, LLC
 */
public class MutableStat {

	public static enum StatModType {
		PERCENT,
		FLAT,
		MULT,
	}
	
	public static class StatMod {
		public String source;
		public String desc = null;
		public StatModType type;
		public float value;
		public StatMod(String source, StatModType type, float value) {
			this.source = source;
			this.type = type;
			this.value = value;
		}
		public StatMod(String source, StatModType type, float value, String desc) {
			this.source = source;
			this.desc = desc;
			this.type = type;
			this.value = value;
		}

		public String getSource() {
			return source;
		}
		public StatModType getType() {
			return type;
		}
		public float getValue() {
			return value;
		}
		public String getDesc() {
			return desc;
		}
		
	}
	
	public float base;
	public float modified;
	
	//private List<StatMod> mods = new LinkedList<StatMod>();
	private HashMap<String, StatMod> flatMods = new HashMap<String, StatMod>();
	private HashMap<String, StatMod> percentMods = new HashMap<String, StatMod>();
	private HashMap<String, StatMod> multMods = new HashMap<String, StatMod>();
	
	private boolean needsRecompute = false;
	public MutableStat(float base) {
		this.base = base;
		modified = base;
	}
	
	public void applyMods(MutableStat other) {
		flatMods.putAll(other.getFlatMods());
		percentMods.putAll(other.getPercentMods());
		multMods.putAll(other.getMultMods());
		needsRecompute = true;
	}
	
	public void applyMods(StatBonus other) {
		flatMods.putAll(other.getFlatBonuses());
		percentMods.putAll(other.getPercentBonuses());
		multMods.putAll(other.getMultBonuses());
		needsRecompute = true;
	}
	
	public HashMap<String, StatMod> getFlatMods() {
		return flatMods;
	}

	public HashMap<String, StatMod> getPercentMods() {
		return percentMods;
	}

	public HashMap<String, StatMod> getMultMods() {
		return multMods;
	}

	public StatMod getFlatStatMod(String source) {
		return flatMods.get(source);
	}
	
	public StatMod getPercentStatMod(String source) {
		return percentMods.get(source);
	}
	
	public StatMod getMultStatMod(String source) {
		return multMods.get(source);
	}
	
	public void modifyFlat(String source, float value) {
		modifyFlat(source, value, null);
	}
	
	public void modifyFlat(String source, float value, String desc) {
		StatMod mod = flatMods.get(source);
		if (mod == null && value == 0) return;
		if (mod != null && mod.value == value) return;
		
		mod = new StatMod(source, StatModType.FLAT, value, desc);
		flatMods.put(source, mod);
		needsRecompute = true;
	}
	
	public void modifyPercent(String source, float value) {
		modifyPercent(source, value, null);
	}
	
	public void modifyPercent(String source, float value, String desc) {
		StatMod mod = percentMods.get(source);
		if (mod == null && value == 0) return;
		if (mod != null && mod.value == value) return;
		
		mod = new StatMod(source, StatModType.PERCENT, value, desc);
		percentMods.put(source, mod);
		needsRecompute = true;
	}
	
	public void modifyMult(String source, float value) {
		modifyMult(source, value, null);
	}
	
	public void modifyMult(String source, float value, String desc) {
		StatMod mod = multMods.get(source);
		if (mod == null && value == 1) return;
		if (mod != null && mod.value == value) return;
		
		mod = new StatMod(source, StatModType.MULT, value, desc);
		multMods.put(source, mod);
		needsRecompute = true;
	}
	
	public void unmodify() {
		flatMods.clear();
		percentMods.clear();
		multMods.clear();
		needsRecompute = true;
	}
	
	public void unmodify(String source) {
		StatMod mod = flatMods.remove(source);
		if (mod != null && mod.value != 0) needsRecompute = true; 
		mod = percentMods.remove(source);
		if (mod != null && mod.value != 0) needsRecompute = true;
		mod = multMods.remove(source);
		if (mod != null && mod.value != 1) needsRecompute = true;
	}
	
	public void unmodifyFlat(String source) {
		StatMod mod = flatMods.remove(source);
		if (mod != null && mod.value != 0) needsRecompute = true;
	}
	
	public void unmodifyPercent(String source) {
		StatMod mod = percentMods.remove(source);
		if (mod != null && mod.value != 0) needsRecompute = true;
	}
	
	public void unmodifyMult(String source) {
		StatMod mod = multMods.remove(source);
		if (mod != null && mod.value != 1) needsRecompute = true;
	}	
	
	private void recompute() {
		float flatMod = 0;
		float percentMod = 0;
		float mult = 1f;
		for (StatMod mod : percentMods.values()) {
			percentMod += mod.value;
		}
		for (StatMod mod : flatMods.values()) {
			flatMod += mod.value;
		}
		for (StatMod mod : multMods.values()) {
			mult *= mod.value;
		}
		
		modified = base + base * percentMod / 100f + flatMod;
		if (modified < 0) modified = 0;
		modified *= mult;
		needsRecompute = false;
	}
	
	public float getModifiedValue() {
		if (needsRecompute) recompute();
		return modified;
	}
	
	public float getBaseValue() {
		return base;
	}

	public boolean isPositive() {
		return getModifiedValue() > getBaseValue();
	}
	
	public boolean isNegative() {
		return getModifiedValue() < getBaseValue();
	}
}











