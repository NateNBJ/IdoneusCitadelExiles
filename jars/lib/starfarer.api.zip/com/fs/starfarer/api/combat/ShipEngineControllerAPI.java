package com.fs.starfarer.api.combat;

import java.util.List;

import org.lwjgl.util.vector.Vector2f;

public interface ShipEngineControllerAPI {
	public interface ShipEngineAPI {
		/**
		 * @return location, in absolute coordinates.
		 */
		Vector2f getLocation();
		
		/**
		 * @return whether this engine is currently engaged (some engines are only "active" when a ship system is in use, for example.)
		 */
		boolean isActive();
		
		/**
		 * @return whether this engine is only shown when the ship system is active.
		 */
		boolean isSystemActivated();
		
		String getStyleId();

		boolean isDisabled();
		void disable();
		void disable(boolean permanent);
		
		/**
		 * Fraction of total engine power this engine provides.
		 * @return
		 */
		float getContribution();
	}
	
	
	boolean isAccelerating();
	boolean isAcceleratingBackwards();
	boolean isDecelerating();
	boolean isTurningLeft();
	boolean isTurningRight();
	boolean isStrafingLeft();
	boolean isStrafingRight();
	
	
	List<ShipEngineAPI> getShipEngines();
	
}
