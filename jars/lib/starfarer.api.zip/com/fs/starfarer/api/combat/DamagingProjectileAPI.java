package com.fs.starfarer.api.combat;

public interface DamagingProjectileAPI extends CombatEntityAPI {
	DamageType getDamageType();
	float getDamageAmount();
	float getEmpAmount();
	
	/**
	 * @return Weapon that fired this projectile. Can be null (for example, if spawned without one via the API).
	 */
	WeaponAPI getWeapon();

	/**
	 * Whether the projectile already did its damage and is now fading out.
	 * @return
	 */
	boolean didDamage();
	
	/**
	 * @return What the damage was dealt to, once didDamage() returns true. Can be null.
	 */
	CombatEntityAPI getDamageTarget();
	
	String getProjectileSpecId();
	
	
	/**
	 * Generally a ShipAPI for the ship that ultimately fired this weapon. Can be null.
	 * 
	 * Projectiles can't hit their source, except for fizzled-out missiles.
	 * 
	 * @return
	 */
	ShipAPI getSource();
	void setSource(ShipAPI source);
	
	/**
	 * @return whether the projectile has started fading out due to exceeding its maximum range.
	 */
	boolean isFading();
}
