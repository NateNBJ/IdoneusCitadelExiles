package com.fs.starfarer.api.combat;

import org.lwjgl.util.vector.Vector2f;

public interface CombatEntityAPI {
	Vector2f getLocation();
	Vector2f getVelocity();
	float getFacing();
	void setFacing(float facing);
	float getAngularVelocity();
	void setAngularVelocity(float angVel);
	
	int getOwner();
	void setOwner(int owner);
	
	float getCollisionRadius();
	
	CollisionClass getCollisionClass();
	void setCollisionClass(CollisionClass collisionClass);

	float getMass();
	void setMass(float mass);
	
	/**
	 * Can return null if there aren't any bounds, in which case just the collision radius should be used.
	 * The bounds are guaranteed to be inside the collision radius.
	 * @return
	 */
	BoundsAPI getExactBounds();
	
	/**
	 * Returns null for entities without shields.
	 * @return
	 */
	ShieldAPI getShield();
	
	/**
	 * @return hull level, normalized to (0, 1)
	 */
	float getHullLevel();
	
	/**
	 * @return actual hull points left
	 */
	float getHitpoints();
	
	/**
	 * @return maximum hull points for the ship
	 */
	float getMaxHitpoints();
}
