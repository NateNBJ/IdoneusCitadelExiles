package com.fs.starfarer.api.combat;

import java.util.EnumSet;
import java.util.List;

import com.fs.starfarer.api.characters.MutableCharacterStatsAPI;
import com.fs.starfarer.api.combat.ShieldAPI.ShieldType;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.loading.WeaponSlotAPI;

public interface ShipHullSpecAPI {
	
	public static enum ShipTypeHints {
		CIVILIAN,
		CARRIER,
	}
	
	ShieldType getDefenseType();
	String getHullId();
	String getHullName();
	
	EnumSet<ShipTypeHints> getHints();
	
	float getNoCRLossTime();
	float getCRToDeploy();
	float getCRLossPerSecond();
	
	float getBaseValue();
	
	int getOrdnancePoints(MutableCharacterStatsAPI stats);
	HullSize getHullSize();
	float getHitpoints();
	float getArmorRating();
	float getFluxCapacity();
	float getFluxDissipation();
	
	ShieldType getShieldType();
	
	List<WeaponSlotAPI> getAllWeaponSlotsCopy();
	
	String getSpriteName();
}
