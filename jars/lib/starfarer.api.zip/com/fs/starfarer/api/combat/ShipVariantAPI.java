package com.fs.starfarer.api.combat;

import java.util.Collection;
import java.util.EnumSet;
import java.util.List;

import com.fs.starfarer.api.characters.MutableCharacterStatsAPI;
import com.fs.starfarer.api.combat.ShipHullSpecAPI.ShipTypeHints;
import com.fs.starfarer.api.loading.VariantSource;
import com.fs.starfarer.api.loading.WeaponGroupSpec;
import com.fs.starfarer.api.loading.WeaponSpecAPI;

public interface ShipVariantAPI {
	ShipVariantAPI clone();
	
	ShipHullSpecAPI getHullSpec();
	
	String getDisplayName();
	String getDesignation();
	List<String> getHullMods();
	
	/**
	 * Doesn't clear out built-in hullmods, as opposed to getHullMods().clear().
	 */
	void clearHullMods();
	
	EnumSet<ShipTypeHints> getHints();
	
	void addMod(String modId);
	void removeMod(String modId);
	
	void addWeapon(String slotId, String weaponId);
	
	int getNumFluxVents();
	int getNumFluxCapacitors();
	
	/**
	 * Only returns slots that have actual weapons in them, not empty slots.
	 * @return
	 */
	List<String> getNonBuiltInWeaponSlots();
	String getWeaponId(String slotId);
	
	void setNumFluxCapacitors(int capacitors);
	void setNumFluxVents(int vents);
	void setSource(VariantSource source);
	void clearSlot(String slotId);
	
	
	WeaponSpecAPI getWeaponSpec(String slotId);
	Collection<String> getFittedWeaponSlots();

	
	void autoGenerateWeaponGroups();
	boolean hasUnassignedWeapons();
	void assignUnassignedWeapons();
	WeaponGroupSpec getGroup(int index);
	
	int computeOPCost(MutableCharacterStatsAPI stats);
	int computeWeaponOPCost(MutableCharacterStatsAPI stats);
	int computeHullModOPCost();
	int computeHullModOPCost(MutableCharacterStatsAPI stats);
	
	VariantSource getSource();
	boolean isStockVariant();
	boolean isEmptyHullVariant();
	
	void setHullVariantId(String hullVariantId);
	String getHullVariantId();

	List<WeaponGroupSpec> getWeaponGroups();
	void addWeaponGroup(WeaponGroupSpec group);
	
	void setVariantDisplayName(String variantName);

	ShipAPI.HullSize getHullSize();

	boolean isFighter();
	int getNumFlightDecks();

	String getFullDesignationWithHullName();
	
}

	
	
	
	
	
	
	
	
	