package com.fs.starfarer.api.combat;


public interface MissileAPI extends DamagingProjectileAPI {
	boolean isFizzling();
	void flameOut();
	
	ShipEngineControllerAPI getEngineController();
	
	
	/**
	 * Only should be called if the AI needs to be changed dynamically. Otherwise,
	 * use ModPlugin.pickMissileAI() instead.
	 * @param ai
	 */
	void setMissileAI(MissileAIPlugin ai);
	
	/**
	 * Does NOT return the same ai passed in to setShipAI(), but a wrapper around it.
	 * Can be used to save/restore the AI. 
	 * @return
	 */
	MissileAIPlugin getMissileAI();
	
	
	
	/**
	 * Should only be used by a MissileAIPlugin.
	 * @param command type of the command. Only movement-related ShipCommands have any effect.
	 */
	void giveCommand(ShipCommand command);
	
	boolean isFlare();
}
