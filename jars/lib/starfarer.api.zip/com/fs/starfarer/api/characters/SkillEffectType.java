package com.fs.starfarer.api.characters;

public enum SkillEffectType {
	SHIP,
	ALL_SHIPS_IN_FLEET,
	CHARACTER_STATS,
	HULLMOD_UNLOCK,
}
