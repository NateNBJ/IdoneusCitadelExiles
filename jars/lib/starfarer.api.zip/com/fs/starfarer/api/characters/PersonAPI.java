package com.fs.starfarer.api.characters;

/**
 * @author Alex Mosolov
 *
 * Copyright 2012 Fractal Softworks, LLC
 */
public interface PersonAPI {
	void setPersonality(String personality);
	
	MutableCharacterStatsAPI getStats();

	String getRank();
	void setRank(String rank);
	
	FullName getName();
	void setName(FullName name);
	
	String getPortraitSprite();
	void setPortraitSprite(String portraitSprite);
}
