package com.fs.starfarer.api.characters;

import com.fs.starfarer.api.combat.MutableStat;
import com.fs.starfarer.api.combat.StatBonus;

public interface MutableCharacterStatsAPI {

	int getLevel();
	long getXP();
	
	
	int getSkillPoints();
	int getAptitudePoints();
	void setSkillPoints(int points);
	void setAptitudePoints(int points);
	
	void addAptitudePoints(int points);
	void addSkillPoints(int points);
	void increaseSkill(String id);
	void increaseAptitude(String id);
	
	void setSkillLevel(String id, float level);
	void setAptitudeLevel(String id, float level);
	float getAptitudeLevel(String id);
	
	/**
	 * Only returns whole numbers. Float is used for convenience to avoid some extra casting. Other methods work likewise.
	 * @param id
	 * @return
	 */
	float getSkillLevel(String id);
	
	void addXP(long xp);
	
	
	MutableStat getWeaponOPCostMult();
	StatBonus getShipOrdnancePointBonus();
	
	StatBonus getSmallWeaponOPCost();
	StatBonus getMediumWeaponOPCost();
	StatBonus getLargeWeaponOPCost();
	
	MutableStat getLogistics();
	MutableStat getEmergencyRepairs();
	
	MutableStat getCommandPoints();
	
	MutableStat getMarineEffectivnessMult();
	MutableStat getCrewXPGainMult();
	
	//MutableStat getFleetSizeTravelPenaltyMult();
	//StatBonus getCombatDeploymentCost();
	
	StatBonus getMaxCapacitorsBonus();
	StatBonus getMaxVentsBonus();
	
	//StatBonus getTravelSpeedBonus();
	
	MutableStat getShipRepairChance();
	
	void levelUpIfNeeded();
}
