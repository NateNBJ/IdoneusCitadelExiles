package com.fs.starfarer.api.characters;

import java.util.List;

import org.lwjgl.util.vector.Vector2f;

import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.fleet.FleetMemberType;

public interface CharacterCreationPlugin {

	
	
	public static interface CharacterCreationData {
		public static String HYPERSPACE_NAME_TOKEN = "Hyperspace";

		String getStartingLocationName();
		void setStartingLocationName(String startingLocationName);
		Vector2f getStartingCoordinates();
		
		PersonAPI getPerson();
		void addStartingShipChoice(String variantId);
		void removeStartingShipChoice(String variantId);
		void addStartingFleetMember(String specId, FleetMemberType type);
		CargoAPI getStartingCargo();
		
		List<String> getStartingShipChoices();
		void clearAdditionalShips();
	}
	
	public static interface Response {
		String getText();
	}
	
	String getPrompt();
	List<Response> getResponses();
	void submit(Response response, CharacterCreationData data);
	void startingShipPicked(String variantId, CharacterCreationData data);
	
	
}
