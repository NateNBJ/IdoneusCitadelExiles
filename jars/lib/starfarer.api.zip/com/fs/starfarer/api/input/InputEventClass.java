package com.fs.starfarer.api.input;

public enum InputEventClass {
	MOUSE_EVENT,
	KEYBOARD_EVENT,
}