package com.fs.starfarer.api.input;

public enum InputEventType {
	MOUSE_UP,
	MOUSE_DOWN,
	MOUSE_MOVE,
	KEY_UP,
	KEY_DOWN,
	KEY_REPEAT,
	MOUSE_SCROLL
}