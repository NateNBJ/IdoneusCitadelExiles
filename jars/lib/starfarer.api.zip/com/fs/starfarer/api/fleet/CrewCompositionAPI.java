package com.fs.starfarer.api.fleet;

import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.CargoAPI.CrewXPLevel;

public interface CrewCompositionAPI {
	float getGreen();
	void setGreen(float green);
	float getRegular();
	void setRegular(float regular);
	float getVeteran();
	void setVeteran(float veteran);
	float getElite();
	void setElite(float elite);
	float getTotalCrew();
	
	float getCrew(CrewXPLevel level);
	
	/**
	 * Generally not set for most crews, but useful to have here for use during boarding/loss calculation/etc.
	 * @param marines
	 */
	void setMarines(float marines);
	/**
	 * Generally not set for most crews, but useful to have here for use during boarding/loss calculation/etc.
	 */
	float getMarines();
	
	void addGreen(float green);
	void addRegular(float regular);
	void addVeteran(float veteran);
	void addElite(float elite);
	
	/**
	 * Generally not set for most crews, but useful to have here for use during boarding/loss calculation/etc.
	 * @param marines
	 */
	void addMarines(float marines);
	
	void removeAllCrew();
	
	void transfer(CargoAPI.CrewXPLevel level, float quantity, CrewCompositionAPI dest);
	void addCrew(CrewXPLevel level, float quantity);
	
	void addAll(CrewCompositionAPI other);
	void removeAll(CrewCompositionAPI other);
	
	void multiplyBy(float mult);
	
	void addToCargo(CargoAPI cargo);
	void removeFromCargo(CargoAPI cargo);
}
