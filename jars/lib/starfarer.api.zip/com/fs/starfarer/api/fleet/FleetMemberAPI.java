package com.fs.starfarer.api.fleet;

import com.fs.starfarer.api.campaign.BuffManagerAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.FleetDataAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipHullSpecAPI;
import com.fs.starfarer.api.combat.ShipVariantAPI;

/**
 * @author Alex Mosolov
 *
 * Copyright 2012 Fractal Softworks, LLC
 */
public interface FleetMemberAPI {
	PersonAPI getCaptain();
	void setCrewXPLevel(CargoAPI.CrewXPLevel crewXP);
	
	
	MutableShipStatsAPI getStats();
	
	String getShipName();
	void setShipName(String name);
	
	/**
	 * Unique id, generated using UUID.
	 * @return
	 */
	String getId();
	
	String getSpecId();
	String getHullId();
	FleetMemberType getType();
	
	boolean isFlagship();
	
	int getNumFlightDecks();
	boolean isCarrier();
	boolean isCivilian();
	void setFlagship(boolean isFlagship);
	int getFleetPointCost();
	boolean isFighterWing();
	boolean isFrigate();
	boolean isDestroyer();
	boolean isCruiser();
	boolean isCapital();
	int getNumFightersInWing();
	CargoAPI.CrewXPLevel getCrewXPLevel();
	float getFuelCapacity();
	float getCargoCapacity();
	float getMinCrew();
	float getNeededCrew();
	float getMaxCrew();
	float getFuelUse();
	
	RepairTrackerAPI getRepairTracker();
	ShipHullSpecAPI getHullSpec();
	PersonAPI getFleetCommander();
	
	
	boolean canBeDeployedForCombat();
	ShipVariantAPI getVariant();
	FleetDataAPI getFleetData();
	
	void setVariant(ShipVariantAPI variant, boolean withRefit, boolean withStatsUpdate);
	CrewCompositionAPI getCrewComposition();
	FleetMemberStatusAPI getStatus();
	
	
	/**
	 * @return number between 0 (no crew at all) and 4 (all elite).
	 */
	float getAverageCrewLevel();
	
	/**
	 * Fraction of crew on the ship, 0 to 1, ignores levels of crew.
	 * @return
	 */
	float getCrewFraction();
	
	
	int getReplacementChassisCount();
	
	
	/**
	 * Probably not needed given the current state of the API.
	 * @param statUpdateNeeded
	 */
	void setStatUpdateNeeded(boolean statUpdateNeeded);
	
	BuffManagerAPI getBuffManager();
	
	boolean isMothballed();
	
	/**
	 * From 0 to 1, CR fraction. Multiplied by number of fighters if fighter wing.
	 * @return
	 */
	float getDeployCost();
	void setCaptain(PersonAPI commander);
	
	/**
	 * Based on deployment points, modified by CR and ordnance points actually used by the variant.
	 * 
	 * Not modified by hull status or captain quality.
	 * @return
	 */
	float getMemberStrength();
	
}



