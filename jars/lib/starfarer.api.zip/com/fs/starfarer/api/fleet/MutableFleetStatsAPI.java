package com.fs.starfarer.api.fleet;

import com.fs.starfarer.api.combat.StatBonus;

public interface MutableFleetStatsAPI {
	
	void addTemporaryModFlat(float durInDays, String source, float value, StatBonus stat);
	void addTemporaryModFlat(float durInDays, String source, String desc, float value, StatBonus stat);
	void addTemporaryModPercent(float durInDays, String source, float value, StatBonus stat);
	boolean hasMod(String source);
	
	
	StatBonus getMovementSpeedMod();
	StatBonus getFleetwideMaxBurnMod();
}
