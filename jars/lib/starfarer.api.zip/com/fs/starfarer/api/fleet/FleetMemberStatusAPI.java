package com.fs.starfarer.api.fleet;


public interface FleetMemberStatusAPI {
	/**
	 * Total hul damage (as a fraction) since resetDamageTaken() was last called.
	 * @return
	 */
	float getHullDamageTaken();
	
	/**
	 * From 0 to 1.
	 * @return
	 */
	float getHullFraction();
	
	/**
	 * After this call, getHullDamageTaken() will return 0 until the ship takes more damage.
	 */
	void resetDamageTaken();
	
	
	/**
	 * Repairs the disabled ship's hull a few percentage points.
	 */
	void repairDisabledABit();
	
	
	void disable();
	void repairFully();
	void repairFullyNoNewFighters();
	
	/**
	 * Applies damage in a random location on the hull. In the case of a fighter wing, first picks a random wing member.
	 * @param hitStrength
	 */
	void applyDamage(float hitStrength);
	
	
	/**
	 * Applied to a random location on get hull, deals guaranteed amount of hull damage, expressed as a fraction of the maximum hull value.
	 * 
	 * 
	 *  
	 * @param fraction
	 */
	void applyHullFractionDamage(float fraction);
	
	
	/**
	 * Useful for applying damage to specific fighters.
	 * 
	 * @param fraction
	 * @param index
	 */
	void applyHullFractionDamage(float fraction, int index);
	
	/**
	 * @return 1, or number of fighters in the wing.
	 */
	int getNumStatuses();
}
