package com.fs.starfarer.api.fleet;

import com.fs.starfarer.api.campaign.CampaignFleetAPI;


public interface FleetLogisticsAPI {
	
	/**
	 * Gets the current logistics value, capped by the personnel in the fleet.
	 * @return
	 */
	float getLogisticsStat();
	
	/**
	 * Logistics capability is capped by total personnel.
	 * (See "maxLogisticsPerPersonnel" in settings.json)
	 * @return
	 */
	float getLogisticsPersonnelCap();
	
	/**
	 * Total supply use per day, including what's actually consumed by ship maintenance.
	 * @return
	 */
	float getTotalSuppliesPerDay();
		
	/**
	 * Similar to getTotalSuppliesPerDay(), but with the full ship maintenance value, regardless of whether that's actually
	 * being consumed. (Ship maintenance always counts fully against the LR, but only supplyConsumptionAtMaxCRMult is actually consumed in supplies
	 * if the CR is at the current maximum.) 
	 * @return
	 */
	float getLogisticalCost();
	
		
	/**
	 * @return 0-2 (never actually 2 as that'd require 0 supply usage)
	 */
	float getLogisticsRating();

	
	float getFuelCostPerLightYear();
	
	/**
	 * How much is actually needed for all repairs to proceed at the best possible rate.
	 * @return
	 */
	//float getMaximumRepairSupplyConsumptionPerDay();
	
	
	float getExcessCargoCapacitySupplyCost();
	float getExcessFuelCapacitySupplyCost();
	float getExcessPersonnelCapacitySupplyCost();
	float getMarineSuppliesPerDay();
	float getCrewSuppliesPerDay();
	
	/**
	 * @return getCrewSuppliesPerDay() + getMarineSuppliesPerDay()
	 */
	float getPersonnelSuppliesPerDay();
	
	/**
	 * Sum of maintenance values for all ships.
	 * @return
	 */
	float getShipMaintenanceLogisticsImpact();
	
	/**
	 * Similar to getShipMaintenanceLogisticsImpact(), but with cost being reduced 
	 * (to supplyConsumptionAtMaxCRMult in settings.json) for ships at max CR.
	 * @return
	 */
	float getShipMaintenanceSupplyCost();

	/**
	 * Supplies per day that will be spent on repairs, including emergency capacity
	 * and "headroom" if the logistics use is below maximum.
	 * @return
	 */
	float getCurrentRepairCapacity();

	/**
	 * The emergency repair capacity is the amount of supplies that can be spent on repairs
	 * w/o counting towards the logistics rating.
	 * @return
	 */
	float getEmergencyRepairCapacity();
	void setEmergencyRepairCapacity(float emergencyRepairCapacity);

	CampaignFleetAPI getFleet();

	
	
	float getTotalRepairSupplyCost();
}
