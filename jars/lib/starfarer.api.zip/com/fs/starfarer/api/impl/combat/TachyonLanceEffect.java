package com.fs.starfarer.api.impl.combat;

import java.awt.Color;

import org.lwjgl.util.vector.Vector2f;

import com.fs.starfarer.api.combat.BeamAPI;
import com.fs.starfarer.api.combat.BeamEffectPlugin;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamageType;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.util.IntervalUtil;

public class TachyonLanceEffect implements BeamEffectPlugin {

	private CombatEntityAPI currentArc = null;
	private IntervalUtil fireInterval = new IntervalUtil(0.2f, 0.3f);
	
	public void advance(float amount, CombatEngineAPI engine, BeamAPI beam) {
		
		if (currentArc != null) {
			if (!engine.isEntityInPlay(currentArc)) {
				currentArc = null;
			}
		}
		
		CombatEntityAPI target = beam.getDamageTarget();
		if (target != null && target instanceof ShipAPI && 
				(target.getShield() == null || !target.getShield().isWithinArc(beam.getTo()))) {
			if (beam.getBrightness() >= 1f) {
				fireInterval.advance(amount);
				if (fireInterval.intervalElapsed()) {
					Vector2f dir = Vector2f.sub(beam.getTo(), beam.getFrom(), new Vector2f());
					if (dir.lengthSquared() > 0) dir.normalise();
					dir.scale(5f);
					Vector2f point = Vector2f.sub(beam.getTo(), dir, new Vector2f());
					float emp = beam.getWeapon().getDerivedStats().getBurstDamage() * .667f;
					float dam = emp * 0.25f;
					engine.spawnEmpArc(beam.getSource(), point, beam.getDamageTarget(), beam.getDamageTarget(),
					//engine.spawnEmpArc(beam.getSource(), beam.getFrom(), beam.getSource(), beam.getDamageTarget(),
									   DamageType.ENERGY, 
									   dam, // damage
									   emp, // emp 
									   100000f, // max range 
									   "tachyon_lance_emp_impact",
									   30f, // thickness
									   new Color(85,25,215,255),
									   new Color(255,255,255,255)
									   );
				}
			}
//			Global.getSoundPlayer().playLoop("system_emp_emitter_loop", 
//											 beam.getDamageTarget(), 1.5f, beam.getBrightness() * 0.5f,
//											 beam.getTo(), new Vector2f());
		}
	}
}
