package com.fs.starfarer.api.impl.campaign;

import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.BuffManagerAPI.Buff;
import com.fs.starfarer.api.combat.HullModEffect;
import com.fs.starfarer.api.combat.HullModFleetEffect;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.fleet.FleetMemberAPI;

public class RepairGantry implements HullModEffect, HullModFleetEffect {
	
	public static final String HULLMOD_ID = "repair_gantry";
	
	public static class GantryBuff implements Buff {
		public boolean wasApplied = false;
		private String buffId;
		
		public GantryBuff(String buffId) {
			this.buffId = buffId; 
		}
		
		public boolean isExpired() {
			return wasApplied;
		}
		public String getId() {
			return buffId;
		}
		public void apply(FleetMemberAPI member) {
//			// this ensures the buff lasts for exactly one frame unless wasApplied is reset (as it is later)
//			wasApplied = true;
//			member.getStats().getBaseRepairRatePercentPerDay().modifyFlat(buffId,
//															(Float) mag.get(member.getHullSpec().getHullSize()));
		}
		public void advance(float days) {
		}
	};
	
	
	public RepairGantry() {

	}
	
	public void advanceInCampaign(FleetMemberAPI member, float amount) {
//		if (member.getFleetData() == null) return;
//		if (!member.canBeDeployedForCombat()) {
//			cleanUpGantryBuffBy(member);
//			return;
//		}
//		
//		FleetDataAPI data = member.getFleetData();
//		
//		int numGantries = 0;
//		int thisGantryIndex = -1;
//		for (FleetMemberAPI curr : data.getMembersListCopy()) {
//			if (!curr.canBeDeployedForCombat()) continue;
//			if (curr.getVariant().getHullMods().contains(HULLMOD_ID)) {
//				if (curr == member) {
//					thisGantryIndex = numGantries;
//				}
//				numGantries++;
//			}
//		}
//		if (numGantries <= 0 || thisGantryIndex == -1) {
//			cleanUpGantryBuffBy(member);
//			return;
//		}
//		
//		int index = 0;
//		GantryBuff buff = getGantryBuffBy(member);
//		for (FleetMemberAPI curr : data.getMembersInPriorityOrder()) {
//			if (!isSuitable(curr)) continue;
//			if (curr == member) continue;
//			
//			if (index == thisGantryIndex) {
//				Buff existing = curr.getBuffManager().getBuff(buff.getId());
//				if (existing == buff) {
//					// make sure it using the same buff rather than reapplying it,
//					// which would trigger a full stat recompute for the entire FLEET every frame
//					buff.wasApplied = false;
//				} else {
//					curr.getBuffManager().addBuff(buff);
//				}
//			} else {
//				curr.getBuffManager().removeBuff(buff.getId());
//			}
//			index++;
//		}
	}
	
//	private boolean isSuitable(FleetMemberAPI member) {
//		if (member.isFighterWing()) return false;
//		if (member.getRepairTracker().isMothballed()) return false;
//		return true;
//	}
//	
//	private void cleanUpGantryBuffBy(FleetMemberAPI member) {
//		if (member.getFleetData() == null) return;
//		FleetDataAPI data = member.getFleetData();
//		GantryBuff buff = getGantryBuffBy(member);
//		for (FleetMemberAPI curr : data.getMembersListCopy()) {
//			curr.getBuffManager().removeBuff(buff.getId());
//		}
//	}
	
//	public static final String REPAIR_GANTRY_KEY = "RepairGantry_PersistentBuffs";
//	
//	// DO NOT do it like this; fleet members from prior save games will remain and cause memory leaks
//	//private Map<FleetMemberAPI, GantryBuff> buffs = new HashMap<FleetMemberAPI, GantryBuff>();
//
//	@SuppressWarnings("unchecked")
//	private GantryBuff getGantryBuffBy(FleetMemberAPI member) {
////		if (true) {
////			String id = HULLMOD_ID + "_" + member.hashCode();
////			return new GantryBuff(id);
////		}
//		
//		Map<FleetMemberAPI, GantryBuff> buffs;
//		if (Global.getSector().getPersistentData().containsKey(REPAIR_GANTRY_KEY)) {
//			buffs = (Map<FleetMemberAPI, GantryBuff>) Global.getSector().getPersistentData().get(REPAIR_GANTRY_KEY);
//		} else {
//			buffs = new HashMap<FleetMemberAPI, GantryBuff>();
//			Global.getSector().getPersistentData().put(REPAIR_GANTRY_KEY, buffs);
//		}
//		
//		new HashMap<FleetMemberAPI, GantryBuff>();
//		GantryBuff buff = buffs.get(member);
//		if (buff == null) {
//			String id = HULLMOD_ID + "_" + member.hashCode();
//			buff = new GantryBuff(id);
//			buffs.put(member, buff);
//		}
//		return buff;
//	}
	

	public void advanceInCombat(ShipAPI ship, float amount) {
	}
	
	public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
	}
	public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
	}
	public boolean isApplicableToShip(ShipAPI ship) {
		return true;
	}

//	static Map mag = new HashMap();
//	static {
//		mag.put(HullSize.FRIGATE, 25f);
//		mag.put(HullSize.DESTROYER, 20f);
//		mag.put(HullSize.CRUISER, 15f);
//		mag.put(HullSize.CAPITAL_SHIP, 10f);
//	}
	
	public static final float EMERGENCY_REPAIRS_BONUS = 10f;
	
	public String getDescriptionParam(int index, HullSize hullSize) {
		if (index == 0) return "" + (int) EMERGENCY_REPAIRS_BONUS;
		if (index == 1) return "" + (int) EMERGENCY_REPAIRS_BONUS;
//		if (index == 0) return "" + ((Float) mag.get(HullSize.FRIGATE)).intValue();
//		if (index == 1) return "" + ((Float) mag.get(HullSize.DESTROYER)).intValue();
//		if (index == 2) return "" + ((Float) mag.get(HullSize.CRUISER)).intValue();
//		if (index == 3) return "" + ((Float) mag.get(HullSize.CAPITAL_SHIP)).intValue();
		return null;
	}

	public void advanceInCampaign(CampaignFleetAPI fleet) {
		
	}

	public void onFleetSync(CampaignFleetAPI fleet) {
		float gantryCount = 0;
		for (FleetMemberAPI member : fleet.getFleetData().getMembersListCopy()) {
			if (member.isMothballed() || !member.canBeDeployedForCombat()) continue;
			
			for (String modId : member.getVariant().getHullMods()) {
				if (HULLMOD_ID.equals(modId)) {
					gantryCount++;
				}
			}
		}
		
		String id = HULLMOD_ID + "_ER_modifier";
		if (gantryCount > 0) {
			fleet.getCommander().getStats().getEmergencyRepairs().modifyFlat(id, gantryCount * 10f, "Repair gantries");
		} else {
			fleet.getCommander().getStats().getEmergencyRepairs().unmodify(id);
		}
		
	}
	
}




