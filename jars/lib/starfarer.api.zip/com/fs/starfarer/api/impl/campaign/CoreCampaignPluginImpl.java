package com.fs.starfarer.api.impl.campaign;

import com.fs.starfarer.api.PluginPick;
import com.fs.starfarer.api.campaign.BaseCampaignPlugin;
import com.fs.starfarer.api.campaign.BattleAutoresolverPlugin;
import com.fs.starfarer.api.campaign.BattleCreationPlugin;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.InteractionDialogPlugin;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.OrbitalStationAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.impl.combat.BattleCreationPluginImpl;

public class CoreCampaignPluginImpl extends BaseCampaignPlugin {

	public String getId() {
		return null;
	}
	
	public boolean isTransient() {
		return false;
	}

	public PluginPick<InteractionDialogPlugin> pickInteractionDialogPlugin(SectorEntityToken interactionTarget) {
		if (interactionTarget instanceof CampaignFleetAPI) {
			return new PluginPick<InteractionDialogPlugin>(new FleetInteractionDialogPluginImpl(), PickPriority.CORE_GENERAL);
		}
		if (interactionTarget instanceof JumpPointAPI) {
			return new PluginPick<InteractionDialogPlugin>(new JumpPointInteractionDialogPluginImpl(), PickPriority.CORE_GENERAL);
		}
		if (interactionTarget instanceof PlanetAPI) {
			return new PluginPick<InteractionDialogPlugin>(new PlanetInteractionDialogPluginImpl(), PickPriority.CORE_GENERAL);
		}
		if (interactionTarget instanceof OrbitalStationAPI) {
			return new PluginPick<InteractionDialogPlugin>(new OrbitalStationInteractionDialogPluginImpl(), PickPriority.CORE_GENERAL);
		}
		return null;
	}

	public PluginPick<BattleCreationPlugin> pickBattleCreationPlugin(SectorEntityToken opponent) {
		if (opponent instanceof CampaignFleetAPI) {
			return new PluginPick<BattleCreationPlugin>(new BattleCreationPluginImpl(), PickPriority.CORE_GENERAL);
		}
		return null;
	}
	
	
	public PluginPick<BattleAutoresolverPlugin> pickBattleAutoresolverPlugin(SectorEntityToken one, SectorEntityToken two) {
		if (one instanceof CampaignFleetAPI && two instanceof CampaignFleetAPI) {
			return new PluginPick<BattleAutoresolverPlugin>(
							new BattleAutoresolverPluginImpl((CampaignFleetAPI) one, (CampaignFleetAPI) two),
							PickPriority.CORE_GENERAL
					   );
		}
		return null;
	}

}




