package com.fs.starfarer.api.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class WeightedRandomPicker<T> {

	private List<T> items = new ArrayList<T>();
	private List<Float> weights = new ArrayList<Float>();
	
	private float total = 0f;
	private final boolean ignoreWeights;
	
	private Random random = null;
	
	public WeightedRandomPicker() {
		this(false);
	}
	
	public WeightedRandomPicker(boolean ignoreWeights) {
		this.ignoreWeights = ignoreWeights;
	}

	public WeightedRandomPicker(Random random) {
		this(false);
		this.random = random;
	}

	public void add(T item) {
		add(item, 1f);
	}
	public void add(T item, float weight) {
		items.add(item);
		weights.add(weight); // + (weights.isEmpty() ? 0 : weights.get(weights.size() - 1)));
		total += weight;
	}
	
	public void remove(T item) {
		int index = items.indexOf(item);
		if (index != -1) {
			items.remove(index);
			float weight = weights.remove(index);
			total -= weight;
		}
	}
	
	public boolean isEmpty() {
		return items.isEmpty();
	}
	
	public List<T> getItems() {
		return items;
	}

	public T pick() {
		if (items.isEmpty()) return null;
		
		if (ignoreWeights) {
			int index = (int) (Math.random() * items.size());
			return items.get(index);
		}
		
		float random;
		if (this.random != null) {
			random = this.random.nextFloat() * total;
		} else {
			random = (float) (Math.random() * total);
		}
		float weightSoFar = 0f;
		int index = 0;
		for (Float weight : weights) {
			weightSoFar += weight;
			if (random <= weightSoFar) break;
			index++;
		}
		return items.get(index);
	}
	
	
}






