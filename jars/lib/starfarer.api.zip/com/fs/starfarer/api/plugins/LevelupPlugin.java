package com.fs.starfarer.api.plugins;

public interface LevelupPlugin {

	long getXPForLevel(int level);
	int getSkillPointsAtLevel(int level);
	int getAptitudePointsAtLevel(int level);
}
