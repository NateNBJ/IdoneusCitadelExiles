package com.fs.starfarer.api.plugins;

import com.fs.starfarer.api.combat.MutableShipStatsAPI;

public interface ShipSystemStatsScript {
	public static enum State {
		IN,
		ACTIVE,
		OUT;
	}
	
	public static class StatusData {
		public String text;
		public boolean isDebuff;
		public StatusData(String text, boolean isDebuff) {
			this.text = text;
			this.isDebuff = isDebuff;
		}
	}
	
	void apply(MutableShipStatsAPI stats, String id, State state, float effectLevel);
	void unapply(MutableShipStatsAPI stats, String id);
	
	StatusData getStatusData(int index, State state, float effectLevel);
}
