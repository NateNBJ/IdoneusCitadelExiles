package com.fs.starfarer.api.loading;

import java.util.EnumSet;

import com.fs.starfarer.api.characters.MutableCharacterStatsAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.combat.WeaponAPI.WeaponType;

public interface WeaponSpecAPI {
	float getOrdnancePointCost(MutableCharacterStatsAPI stats);
	EnumSet<WeaponAPI.AIHints> getAIHints();
	
	WeaponType getType();
	float getAmmoPerSecond();
}
