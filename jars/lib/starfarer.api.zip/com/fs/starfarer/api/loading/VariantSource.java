/**
 * 
 */
package com.fs.starfarer.api.loading;

public enum VariantSource {
	STOCK,
	MISSION_DESIGN,
	MISSION_SAVE,
	REFIT,
	HULL,
}