/**
 * 
 */
package com.fs.starfarer.api.loading;


public enum WingRole {
	BOMBER,
	FIGHTER,
	INTERCEPTOR,
	ASSAULT,
	SUPPORT,
}