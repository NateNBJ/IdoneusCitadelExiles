package com.fs.starfarer.api.loading;

public class Description {

	public static enum Type {
		SHIP,
		WEAPON,
		SHIP_SYSTEM,
		RESOURCE,
		ACTION_TOOLTIP,
		PLANET,
		ASTEROID,
		CUSTOM,
	}
	
	private Type type;
	private String id;
	
	private String text1 ="No description... yet", text2 ="No description... yet", text3 ="No description... yet";

	public Description(String id, Type type) {
		this.type = type;
		this.id = id;
	}
	
	public String getUID() {
		return id + "_" + type.name();
	}

	public String getText1() {
		return text1;
	}
	
	public String getText1FirstPara() {
		if (text1 != null) {
			int index = text1.indexOf('\n');
			if (index != -1) {
				return text1.substring(0, index);
			}
		}
		return text1;
	}

	
	public void setText1(String text1) {
		if (text1 == null || text1.equals("")) text1 = "No description... yet";
		this.text1 = text1;
	}

	public String getText2() {
		return text2;
	}

	public void setText2(String text2) {
		if (text2 == null || text2.equals("")) text2 = "No description... yet";
		this.text2 = text2;
	}

	public String getText3() {
		return text3;
	}

	public void setText3(String text3) {
		if (text3 == null || text3.equals("")) text3 = "No description... yet";
		this.text3 = text3;
	}
	
	public boolean hasText2() {
		String str = getText2();
		if (str == null || str.isEmpty() || str.equals("No description... yet")) return false;
		return true;
	}
	public boolean hasText1() {
		String str = getText1();
		if (str == null || str.isEmpty() || str.equals("No description... yet")) return false;
		return true;
	}
	public boolean hasText3() {
		String str = getText3();
		if (str == null || str.isEmpty() || str.equals("No description... yet")) return false;
		return true;
	}
	
}
