/**
 * 
 */
package com.fs.starfarer.api.loading;

public enum FormationType {
	V,
	CLAW,
	DIAMOND,
	BOX,
}