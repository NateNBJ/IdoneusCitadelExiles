/**
 * 
 */
package com.fs.starfarer.api.ui;

public enum ValueDisplayMode {
	PERCENT,
	VALUE,
	X_OVER_Y,
	X_OVER_Y_NO_SPACES,
	NONE,
}