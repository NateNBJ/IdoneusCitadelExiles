package com.fs.starfarer.api;

import org.lwjgl.util.vector.Vector2f;

/**
 * @author Alex Mosolov
 *
 * Copyright 2013 Fractal Softworks, LLC
 */
public interface SoundPlayerAPI {
	/**
	 * UI sound files should be stereo.
	 * @param id
	 * @param pitch
	 * @param volume
	 */
	void playUISound(String id, float pitch, float volume);
	
	/**
	 * Sound file must be *mono* for it to be properly played within the engine.
	 * @param id
	 * @param pitch
	 * @param volume
	 * @param loc
	 * @param vel
	 * @return
	 */
	SoundAPI playSound(String id, float pitch, float volume, Vector2f loc, Vector2f vel);
	
	/**
	 * Loop a sound. Must be called every frame or the loop will fade out. Should be mono.
	 * 
	 * @param id
	 * @param playingEntity Required. Used to help uniquely identify playing loops. Also used to figure out which loops to not play (i.e., same entity playing multiples of the same loop would only play the one.)
	 * @param pitch
	 * @param volume
	 * @param loc
	 * @param vel
	 */
	void playLoop(String id, Object playingEntity, float pitch, float volume, Vector2f loc, Vector2f vel);
}


