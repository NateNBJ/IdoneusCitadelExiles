package com.fs.starfarer.api;

import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.OrbitAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.fleet.CrewCompositionAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.fleet.FleetMemberType;

/**
 * @author Alex Mosolov
 *
 * Copyright 2012 Fractal Softworks, LLC
 */
public interface FactoryAPI {
	FleetMemberAPI createFleetMember(FleetMemberType type, String variantOrWingId);
	CargoAPI createCargo(boolean unlimitedStacks);
	CrewCompositionAPI createCrewComposition();

	JumpPointAPI createJumpPoint(String name);
	OrbitAPI createCircularOrbit(SectorEntityToken focus, float angle, float orbitRadius, float orbitDays);
}
