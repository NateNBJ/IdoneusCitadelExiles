package com.fs.starfarer.api;

public interface DataAPI {

//	Object getProjectileSpec(String weaponId);
}
